const Header = () => {
	return (
		<section>
			<div className="header-img"></div>
		</section>
	);
};

export default Header;
